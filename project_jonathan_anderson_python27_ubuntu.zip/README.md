#Python Puzzle

För att köra spelet kör main.py

Spelet är utvecklat i Python 2.7.12 under Ubuntu 16.04 med pygame 1.9.1release

Video demo: https://youtu.be/VwaRSit16qI

De 2 ljuden som används i spelet är båda under Public Domain:
victory.mp3 är hämtad från http://www.freesound.org/people/unadamlar/sounds/341985/ CC0 1.0 Universal (CC0 1.0) Public Domain Dedication
fail.mp3 är hämtad från http://www.freesound.org/people/LittleRainySeasons/sounds/335906/ CC0 1.0 Universal (CC0 1.0) Public Domain Dedication
