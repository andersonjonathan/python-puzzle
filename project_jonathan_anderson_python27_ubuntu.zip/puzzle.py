# coding=utf-8
# Namn: Jonathan Anderson
# Python version: 2.7.12
# OS: ubuntu 16.04
import os
import copy
from random import shuffle

LEVEL_PATH = os.path.join(os.path.dirname(__file__), 'levels')


def get_levels():
    """Function for reading the levels folder"""
    files = os.listdir(LEVEL_PATH)
    levels = []
    for f in files:
        if f.endswith(".lvl"):
            levels.append(int(f.replace('.lvl', '')))
    return sorted(levels)


def get_lock_status():
    """Get the lock status for the levels"""
    levels = {}
    try:
        f = open(os.path.join(os.path.dirname(__file__), 'data', 'levels.txt'), 'r')
    except IOError:
        # The file doesn't exist
        _generate_levels_file()
        f = open(os.path.join(os.path.dirname(__file__), 'data', 'levels.txt'), 'r')
    for line in f:
        fields = line.strip().split()
        levels[fields[0]] = fields[1]
    file_levels = get_levels()
    if file_levels != sorted([int(i) for i in levels.keys()]):
        # The levels in the level folder have changed
        _update_levels_file(file_levels, levels)
        f = open(os.path.join(os.path.dirname(__file__), 'data', 'levels.txt'), 'r')
        for line in f:
            fields = line.strip().split()
            levels[fields[0]] = fields[1]
    return levels


def update_lock_status_on_level(level):
    """Update the lock status on a level"""
    levels = get_lock_status()
    levels[str(level)] = '1'
    _update_levels_file(get_levels(), levels)


def _update_levels_file(file_levels, levels):
    """Internal function for updating the data in the levels file."""
    lvl = open(os.path.join(os.path.dirname(__file__), 'data', 'levels.txt'), 'w')
    reset_rest = False
    for f in file_levels:
        if str(f) in levels and not reset_rest:
            lvl.write(str(f) + " " + str(levels[str(f)]) + "\n")
        else:
            reset_rest = True
            lvl.write(str(f) + " " + str(0) + "\n")


def _generate_levels_file():
    """Generate the levels file"""
    lvl = open(os.path.join(os.path.dirname(__file__), 'data', 'levels.txt'), 'w')
    files = os.listdir(LEVEL_PATH)
    for f in files:
        if f.endswith(".lvl"):
            lvl.write(str(int(f.replace('.lvl', ''))) + " " + str(0) + "\n")


class Level:
    def __init__(self, lvl):
        """Function for reading and parsing a level file"""
        exec(open(os.path.join(LEVEL_PATH, lvl)).read())
        self.nr = int(lvl.replace('.lvl', ''))
        self.name = locals()['name']
        self.variables = locals()['variables']
        self.init_values = locals()['init_values']
        self.goal_values = locals()['goal_values']
        self.pieces = locals()['pieces']
        self.clue = locals()['clue'].split('\n')
        self.values = copy.deepcopy(self.init_values)

    def reset_level(self):
        """Reset the value to the initial"""
        self.values = copy.deepcopy(self.init_values)

    @property
    def passed(self):
        """Check if level is passed"""
        tmp = True
        for i, v in enumerate(self.variables):
            if self.values[i] != self.goal_values[i]:
                tmp = False
        return tmp

    def execute_snippet(self, snippet_nr):
        """Execute a snippet"""
        for i, v in enumerate(self.variables):
            locals()[v] = self.values[i]
        exec(self.pieces[snippet_nr])
        for i, v in enumerate(self.variables):
            exec("self.values[i] = {}".format(v))

    def execute_snippet_list(self, snippet_list):
        """Execute a list of snippets"""
        for s in snippet_list:
            self.execute_snippet(s)

    @classmethod
    def get_level(cls, nr):
        """Get level file from number"""
        return Level(lvl=str(nr).zfill(4)+'.lvl')

    def shuffle_snippets(self):
        """Shuffle the code snippets"""
        shuffle(self.pieces)
